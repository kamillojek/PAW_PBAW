\$right\_delimiter {#variable.right.delimiter}
==================

This is the right delimiter used by the template language. Default is
`}`.

See also [`$left_delimiter`](#variable.left.delimiter) and [escaping
smarty parsing](#language.escaping).
