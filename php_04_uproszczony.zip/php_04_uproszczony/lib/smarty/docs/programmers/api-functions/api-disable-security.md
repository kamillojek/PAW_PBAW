disableSecurity()

disables template security

Description
===========

string

disableSecurity

This disables securty checking on templates.

See also [`enableSecurity()`](#api.enable.security), and
[Security](#advanced.features.security).
