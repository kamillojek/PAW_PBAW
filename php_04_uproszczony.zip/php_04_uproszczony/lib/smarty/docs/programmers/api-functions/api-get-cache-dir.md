getCacheDir()

return the directory where the rendered template\'s output is stored

Description
===========

string

getCacheDir


    <?php

    // get directory where compiled templates are stored
    $cacheDir = $smarty->getCacheDir();

    ?>

       

See also [`setCacheDir()`](#api.set.cache.dir) and
[`$cache_dir`](#variable.cache.dir).
