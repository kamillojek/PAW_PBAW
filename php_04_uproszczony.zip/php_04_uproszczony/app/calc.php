<?php
// KONTROLER strony kalkulatora
require_once dirname(__FILE__).'/../config.php';
//załaduj Smarty
require_once _ROOT_PATH.'/lib/smarty/libs/Smarty.class.php';

//pobranie parametrów
function getParams(&$form){
    $form['kwota'] = isset($_REQUEST ['kwota']) ? $_REQUEST['kwota'] : null;
    $form['oprocentowanie'] = isset($_REQUEST ['oprocentowanie']) ? $_REQUEST['oprocentowanie'] : null;
    $form['raty'] = isset($_REQUEST ['raty']) ? $_REQUEST['raty'] : null;
}
//walidacja parametrów z przygotowaniem zmiennych dla widoku
function validate(&$form,&$infos,&$msgs,&$hide_intro){

    //sprawdzenie, czy parametry zostały przekazane - jeśli nie to zakończ walidację
    if ( ! (isset($form['kwota']) && isset($form['oprocentowanie']) && isset($form['raty']) ))	return false;

    //parametry przekazane zatem
    //nie pokazuj wstępu strony gdy tryb obliczeń (aby nie trzeba było przesuwać)
    // - ta zmienna zostanie użyta w widoku aby nie wyświetlać całego bloku itro z tłem
    $hide_intro = true;

    $infos [] = 'Przekazano parametry.';
// sprawdzenie, czy potrzebne wartości zostały przekazane
    if ( $form['kwota'] == "") $msgs [] = 'Nie podano kwoty';
    if ( $form['oprocentowanie'] == "") $msgs [] = 'Nie podano oprocentowania';
    if ( $form['raty'] == "") $msgs [] = 'Nie podano rat';

    //nie ma sensu walidować dalej gdy brak parametrów
    if ( count($msgs)==0 ) {
        // sprawdzenie, czy $x i $y są liczbami całkowitymi
        if (! is_numeric( $form['kwota'] )) $msgs [] = 'Kwota nie jest liczbą całkowitą';
        if (! is_numeric( $form['raty'] )) $msgs [] = 'Raty muszą być liczbą całkowitą >0';
    }

    if (count($msgs)>0) return false;
    else return true;
}



    function process(&$form,&$infos,&$msgs, &$wynik){
        $infos [] = 'Parametry poprawne. Wykonuję obliczenia.';

        //konwersja parametrów na int
        $form['kwota'] = floatval($form['kwota']);
        $form['raty'] = floatval($form['raty']);
        $form['oprocentowanie'] = floatval($form['oprocentowanie']);



    $q = 1+(($form['oprocentowanie']/100)/12);
    $lata = $form['raty'] * 12;

    //wykonanie operacji
        $rata = $form['kwota']*pow($q, $lata)*($q-1)/((pow($q, $lata))-1);
        $wynik = round($rata, 2);


}

//definicja zmiennych kontrolera
$form = null;
$infos = array();
$wynik = null;
$messages = array();

getParams($form);
if ( validate($form,$infos,$messages,$hide_intro) ){
    process($form,$infos,$messages,$wynik);
}

// 4. Przygotowanie danych dla szablonu

$smarty = new Smarty();

$smarty->assign('app_url',_APP_URL);
$smarty->assign('root_path',_ROOT_PATH);
$smarty->assign('page_title','Przykład 04');
$smarty->assign('page_description','Profesjonalne szablonowanie oparte na bibliotece Smarty');
$smarty->assign('page_header','Szablony Smarty');

//pozostałe zmienne niekoniecznie muszą istnieć, dlatego sprawdzamy aby nie otrzymać ostrzeżenia
$smarty->assign('form',$form);
$smarty->assign('wynik',$wynik);
$smarty->assign('messages',$messages);
$smarty->assign('infos',$infos);


// 5. Wywołanie szablonu
$smarty->display(_ROOT_PATH.'/app/calc.html');