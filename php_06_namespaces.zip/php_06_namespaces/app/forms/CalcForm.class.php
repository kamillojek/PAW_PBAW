<?php

namespace app\forms;

class CalcForm {
    public $kwota;
    public $oprocentowanie;
    public $raty;
} 